
* XOR2 Functional Testbench - ASAP7
.option post=2
.option accurate

* Supply voltage
.param VDD_VAL = 0.9
VDD_SRC VDD 0 DC 0.9

* Input A: 0, 0, 1, 1
VA A 0 PWL(0n 0 3.99n 0 4n 0.9 8n 0.9)

* Input B: 0, 1, 0, 1
VB B 0 PWL(0n 0 1.99n 0 2n 0.9
+ 3.99n 0.9 4n 0 5.99n 0
+ 6n 0.9 8n 0.9)

* Include your ASAP7 transistor models here
* .include '/path/to/asap7_models.sp'

* Include your XOR2 transistor-level netlist
.include 'XOR2.sp'

* IMPORTANT: Match the pin order in .SUBCKT XOR2
* Example assumes: A B Y VDD VSS
XU1 A B Y VDD 0 XOR2

* Output load
CLOAD Y 0 1f

* Transient simulation
.tran 1p 8n

* Save waveforms
.probe tran V(A) V(B) V(Y)

.end
