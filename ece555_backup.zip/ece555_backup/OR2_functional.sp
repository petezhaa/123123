OR2 ASAP7 RVT Functional Simulation

.include '/srv/auto/apps/asap7pdk/2022-fixed/asap7PDK_r1p7/models/hspice/7nm_TT_160803.pm'

.option post=2
.temp 25

* OR2 = NOR2 followed by inverter

* Series PMOS pull-up
M4 nmid A VDD VDD pmos_rvt w=162n l=20n nfin=6
M5 nor B nmid VDD pmos_rvt w=162n l=20n nfin=6

* Parallel NMOS pull-down
M2 nor A VSS VSS nmos_rvt w=81n l=20n nfin=3
M3 nor B VSS VSS nmos_rvt w=81n l=20n nfin=3

* Output inverter
M1 Y nor VDD VDD pmos_rvt w=81n l=20n nfin=3
M0 Y nor VSS VSS nmos_rvt w=81n l=20n nfin=3

* Supplies
VDD_SRC VDD 0 DC 0.9
VSS_SRC VSS 0 DC 0

* Test inputs
* 0.00-0.20 ns: A=0 B=0
* 0.20-0.40 ns: A=1 B=0
* 0.40-0.60 ns: A=0 B=1
* 0.60-0.90 ns: A=1 B=1

VA A 0 PWL(0n 0 0.19n 0 0.20n 0.9
+ 0.39n 0.9 0.40n 0 0.59n 0
+ 0.60n 0.9 0.90n 0.9)

VB B 0 PWL(0n 0 0.39n 0
+ 0.40n 0.9 0.90n 0.9)

.tran 1p 0.9n

* Measure settled outputs
.measure tran y_00 FIND v(Y) AT=0.15n
.measure tran y_10 FIND v(Y) AT=0.35n
.measure tran y_01 FIND v(Y) AT=0.55n
.measure tran y_11 FIND v(Y) AT=0.80n

.probe tran v(A) v(B) v(Y)

.end
