* SPICE NETLIST
***************************************

.SUBCKT AND2 VSS VDD A B C
** N=13 EP=5 IP=0 FDC=8
M0 7 A VSS VSS nmos_rvt L=2e-08 W=5.4e-08 nfin=2 $X=284 $Y=216 $D=1
M1 5 B 7 VSS nmos_rvt L=2e-08 W=5.4e-08 nfin=2 $X=500 $Y=216 $D=1
M2 8 B 5 VSS nmos_rvt L=2e-08 W=5.4e-08 nfin=2 $X=716 $Y=216 $D=1
M3 VSS A 8 VSS nmos_rvt L=2e-08 W=5.4e-08 nfin=2 $X=932 $Y=216 $D=1
M4 C 5 VSS VSS nmos_rvt L=2e-08 W=5.4e-08 nfin=2 $X=1148 $Y=216 $D=1
M5 5 A VDD VDD pmos_rvt L=2e-08 W=1.62e-07 nfin=6 $X=284 $Y=648 $D=0
M6 VDD B 5 VDD pmos_rvt L=2e-08 W=1.62e-07 nfin=6 $X=500 $Y=648 $D=0
M7 C 5 VDD VDD pmos_rvt L=2e-08 W=8.1e-08 nfin=3 $X=1148 $Y=648 $D=0
.ENDS
***************************************
