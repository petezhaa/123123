
AND2 RVT ASAP7 Post-Layout FO4 Timing Test
* ECE555 Homework 3
* Extracted driver + schematic-level FO4 loads

.include '/srv/auto/apps/asap7pdk/2022-fixed/asap7PDK_r1p7/models/hspice/7nm_TT_160803.pm'
.include '/userspace/alanka/ece555_backup/pex/AND2.pex.netlist'

.option post=2
.temp 25

* Original HW2 schematic used for FO4 loads
.subckt AND2_LOAD a b c vdd vss
m0 net1 a vdd vdd pmos_rvt w=27n l=20n nfin=1
m1 net1 b vdd vdd pmos_rvt w=27n l=20n nfin=1
m2 net1 a net7 vss nmos_rvt w=27n l=20n nfin=1
m3 net7 b vss vss nmos_rvt w=162n l=20n nfin=6
m4 c net1 vdd vdd pmos_rvt w=81n l=20n nfin=3
m5 c net1 vss vss nmos_rvt w=54n l=20n nfin=2
.ends AND2_LOAD

* Extracted AND2 pin order: VSS VDD A B C
* Main post-layout AND2 driver
xi0 vss vdd a b c AND2

* Four schematic-level FO4 loads
xi1 c vdd out1 vdd vss AND2_LOAD
xi2 c vdd out2 vdd vss AND2_LOAD
xi3 c vdd out3 vdd vss AND2_LOAD
xi4 c vdd out4 vdd vss AND2_LOAD

* Power supplies
vddsrc vdd 0 DC 0.9
vsssrc vss 0 DC 0

* Input B held HIGH
vbin b 0 DC 0.9
vain a 0 PULSE(0 0.9 100p 25p 25p 175p 400p)

* Transient simulation
.tran 1p 2n
.probe tran v(a) v(b) v(c)

* Propagation delays
.measure tran tLH TRIG v(a) VAL=0.45 RISE=2 TARG v(c) VAL=0.45 RISE=2
.measure tran tHL TRIG v(a) VAL=0.45 FALL=2 TARG v(c) VAL=0.45 FALL=2

* Rise/fall times
.measure tran trise TRIG v(c) VAL=0.09 RISE=2 TARG v(c) VAL=0.81 RISE=2
.measure tran tfall TRIG v(c) VAL=0.81 FALL=2 TARG v(c) VAL=0.09 FALL=2

.end

