AND2 RVT ASAP7 Post-Layout Functional Simulation
* ECE555 Homework 3 - Part C
* Extracted AND2 driver with schematic-level FO4 loads
* Functional sequence: 00 -> 10 -> 01 -> 11

.include '/srv/auto/apps/asap7pdk/2022-fixed/asap7PDK_r1p7/models/hspice/7nm_TT_160803.pm'
.include '/userspace/alanka/ece555_backup/pex/AND2.pex.netlist'

.option post=2
.temp 25

* HW2 schematic-level AND2 used only for FO4 loading
.subckt AND2_LOAD a b c vdd vss
m0 net1 a vdd vdd pmos_rvt w=27n l=20n nfin=1
m1 net1 b vdd vdd pmos_rvt w=27n l=20n nfin=1
m2 net1 a net7 vss nmos_rvt w=27n l=20n nfin=1
m3 net7 b vss vss nmos_rvt w=162n l=20n nfin=6
m4 c net1 vdd vdd pmos_rvt w=81n l=20n nfin=3
m5 c net1 vss vss nmos_rvt w=54n l=20n nfin=2
.ends AND2_LOAD

* PEX AND2 pin order: VSS VDD A B C
xi0 vss vdd a b c AND2

* Four schematic-level loads on A input, B tied high
xi1 c vdd out1 vdd vss AND2_LOAD
xi2 c vdd out2 vdd vss AND2_LOAD
xi3 c vdd out3 vdd vss AND2_LOAD
xi4 c vdd out4 vdd vss AND2_LOAD

* Supply
vddsrc vdd 0 DC 0.9
vsssrc vss 0 DC 0

* Truth table stimulus (settle before each change)
* 0.00-0.20ns: A=0 B=0 -> C=0
* 0.20-0.40ns: A=1 B=0 -> C=0
* 0.40-0.60ns: A=0 B=1 -> C=0
* 0.60-0.90ns: A=1 B=1 -> C=1
vain a 0 PWL(0n 0 0.19n 0 0.20n 0.9 0.39n 0.9
+ 0.40n 0 0.59n 0 0.60n 0.9 0.90n 0.9)
vbin b 0 PWL(0n 0 0.39n 0 0.40n 0.9 0.90n 0.9)

.tran 1p 0.9n
.probe tran v(a) v(b) v(c)
.end
