AND2 RVT ASAP7 Post-Layout FO4 Timing Test
* ECE555 Homework 3 - Post-layout simulation

.include '/srv/auto/apps/asap7pdk/2022-fixed/asap7PDK_r1p7/models/hspice/7nm_TT_160803.pm'

* Calibre extracted layout with parasitic R and C
.include '/userspace/alanka/ece555_backup/pex/AND2.pex.netlist'

.option post=2
.temp 25

* Extracted AND2 pin order: VSS VDD A B C
* One driven AND2 with four AND2 A-input loads

xi0 vss vdd a b c AND2

xi1 vss vdd c vdd out1 AND2
xi2 vss vdd c vdd out2 AND2
xi3 vss vdd c vdd out3 AND2
xi4 vss vdd c vdd out4 AND2

* Power supplies
vddsrc vdd 0 DC 0.9
vsssrc vss 0 DC 0

* Input B held high, A toggles
vbin b 0 DC 0.9
vain a 0 PULSE(0 0.9 100p 25p 25p 175p 400p)

* Transient simulation
.tran 1p 2n

* Save waveforms for part (c)
.probe tran v(a) v(b) v(c)

* Propagation delays at 50% VDD
.measure tran tLH TRIG v(a) VAL=0.45 RISE=2 TARG v(c) VAL=0.45 RISE=2
.measure tran tHL TRIG v(a) VAL=0.45 FALL=2 TARG v(c) VAL=0.45 FALL=2

* Output transition times (10%-90%)
.measure tran trise TRIG v(c) VAL=0.09 RISE=2 TARG v(c) VAL=0.81 RISE=2
.measure tran tfall TRIG v(c) VAL=0.81 FALL=2 TARG v(c) VAL=0.09 FALL=2

.end

